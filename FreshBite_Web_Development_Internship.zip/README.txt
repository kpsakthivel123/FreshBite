FRESHBITE - WEB DEVELOPMENT INTERNSHIP PROJECT

Technology:
PHP + MySQL + HTML + CSS

FEATURES:
1. Restaurant listings
2. Menu management/display
3. Add/remove cart and total calculation
4. Checkout and order tracking
5. Demo payment method (no real payment gateway)

XAMPP SETUP:
1. Copy the FreshBite folder to C:\xampp\htdocs\
2. Start Apache and MySQL in XAMPP.
3. Open http://localhost/phpmyadmin
4. Create/import database.sql.
5. Open http://localhost/FreshBite/

NOTE:
This is a demo academic/internship project. The "Demo Online Payment" option is only a placeholder and does not process real payments.
