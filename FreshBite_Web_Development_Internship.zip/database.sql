CREATE DATABASE IF NOT EXISTS freshbite;
USE freshbite;

CREATE TABLE restaurants (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 cuisine VARCHAR(100) NOT NULL
);

CREATE TABLE menu_items (
 id INT AUTO_INCREMENT PRIMARY KEY,
 restaurant_id INT NOT NULL,
 name VARCHAR(100) NOT NULL,
 description VARCHAR(255),
 price DECIMAL(10,2) NOT NULL,
 FOREIGN KEY (restaurant_id) REFERENCES restaurants(id)
);

CREATE TABLE orders (
 id INT AUTO_INCREMENT PRIMARY KEY,
 customer_name VARCHAR(100) NOT NULL,
 phone VARCHAR(30) NOT NULL,
 address TEXT NOT NULL,
 total DECIMAL(10,2) NOT NULL,
 payment_method VARCHAR(50) NOT NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'Placed',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE order_items (
 id INT AUTO_INCREMENT PRIMARY KEY,
 order_id INT NOT NULL,
 item_id INT NOT NULL,
 quantity INT NOT NULL,
 price DECIMAL(10,2) NOT NULL,
 FOREIGN KEY (order_id) REFERENCES orders(id),
 FOREIGN KEY (item_id) REFERENCES menu_items(id)
);

INSERT INTO restaurants(name,cuisine) VALUES
('FreshBite Kitchen','Indian'),
('Spice Hub','South Indian'),
('Burger House','Fast Food');

INSERT INTO menu_items(restaurant_id,name,description,price) VALUES
(1,'Veg Biryani','Aromatic vegetable biryani',120),
(1,'Paneer Rice','Paneer with flavoured rice',140),
(1,'Chicken Biryani','Classic chicken biryani',180),
(2,'Masala Dosa','Crispy dosa with chutney',70),
(2,'Idli','Soft idli with sambar',50),
(2,'Poori Masala','Poori served with potato masala',80),
(3,'Veg Burger','Fresh vegetable burger',100),
(3,'Chicken Burger','Crispy chicken burger',150),
(3,'French Fries','Crispy salted fries',80);
