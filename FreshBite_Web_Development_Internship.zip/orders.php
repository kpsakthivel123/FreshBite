<?php
session_start(); require "db.php";
$orders=$conn->query("SELECT * FROM orders ORDER BY id DESC");
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Orders</title><link rel="stylesheet" href="style.css"></head>
<body><header><div class="brand">🍴 FreshBite</div><nav><a href="index.php">Menu</a><a href="cart.php">Cart</a></nav></header>
<main><h1>Order Tracking</h1>
<?php if(isset($_GET['success'])): ?><div class="success">Order #<?=htmlspecialchars($_GET['success'])?> placed successfully!</div><?php endif; ?>
<?php while($o=$orders->fetch_assoc()): ?>
<div class="order"><div><b>Order #<?=$o['id']?></b><p><?=htmlspecialchars($o['customer_name'])?> • ₹<?=number_format($o['total'],2)?></p></div><span class="status"><?=htmlspecialchars($o['status'])?></span></div>
<?php endwhile; ?>
</main></body></html>