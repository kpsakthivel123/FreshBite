<?php
session_start();
require "db.php";

$restaurants = $conn->query("SELECT * FROM restaurants ORDER BY name");
$selected = isset($_GET['restaurant']) ? (int)$_GET['restaurant'] : 0;
if ($selected) {
    $stmt = $conn->prepare("SELECT * FROM menu_items WHERE restaurant_id=? ORDER BY name");
    $stmt->bind_param("i", $selected);
    $stmt->execute();
    $items = $stmt->get_result();
} else {
    $items = $conn->query("SELECT m.*, r.name AS restaurant_name FROM menu_items m JOIN restaurants r ON m.restaurant_id=r.id ORDER BY r.name,m.name");
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>FreshBite - Online Food Ordering</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header><div class="brand">🍴 FreshBite</div><nav><a href="index.php">Home</a><a href="cart.php">Cart 🛒 (<?= count($_SESSION['cart'] ?? []) ?>)</a><a href="orders.php">My Orders</a></nav></header>
<main>
<section class="hero"><h1>Fresh food, delivered fast.</h1><p>Choose a restaurant and order your favourite food.</p></section>
<h2>Restaurants</h2>
<div class="restaurants">
<?php while($r=$restaurants->fetch_assoc()): ?>
<a class="restaurant <?= $selected==$r['id']?'active':'' ?>" href="?restaurant=<?=$r['id']?>"><b><?=htmlspecialchars($r['name'])?></b><span><?=htmlspecialchars($r['cuisine'])?></span></a>
<?php endwhile; ?>
</div>
<h2>Menu</h2>
<div class="grid">
<?php while($m=$items->fetch_assoc()): ?>
<div class="card">
<div class="food">🍽️</div><h3><?=htmlspecialchars($m['name'])?></h3>
<p><?=htmlspecialchars($m['description'])?></p>
<p class="price">₹<?=number_format($m['price'],2)?></p>
<form method="post" action="cart.php"><input type="hidden" name="item_id" value="<?=$m['id']?>"><button name="add" value="1">Add to Cart</button></form>
</div>
<?php endwhile; ?>
</div>
</main>
<footer>FreshBite Internship Project • Demo payment only</footer>
</body></html>