<?php
session_start(); require "db.php";
if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

if (isset($_POST['add'])) {
    $id=(int)$_POST['item_id'];
    $_SESSION['cart'][$id]=($_SESSION['cart'][$id]??0)+1;
    header("Location: cart.php"); exit;
}
if (isset($_GET['remove'])) {
    unset($_SESSION['cart'][(int)$_GET['remove']]);
    header("Location: cart.php"); exit;
}
if (isset($_POST['clear'])) { $_SESSION['cart']=[]; header("Location: cart.php"); exit; }

$cart=$_SESSION['cart']; $total=0; $rows=[];
if ($cart) {
    $ids=implode(',',array_map('intval',array_keys($cart)));
    $res=$conn->query("SELECT * FROM menu_items WHERE id IN ($ids)");
    while($r=$res->fetch_assoc()){ $r['qty']=$cart[$r['id']]; $r['subtotal']=$r['qty']*$r['price']; $total+=$r['subtotal']; $rows[]=$r; }
}
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cart - FreshBite</title><link rel="stylesheet" href="style.css"></head>
<body><header><div class="brand">🍴 FreshBite</div><nav><a href="index.php">Menu</a><a href="orders.php">My Orders</a></nav></header>
<main><h1>Your Cart</h1>
<?php if(!$rows): ?><div class="empty">Your cart is empty. <a href="index.php">Browse menu</a></div>
<?php else: ?>
<div class="table">
<?php foreach($rows as $r): ?><div class="cartrow"><div><b><?=htmlspecialchars($r['name'])?></b><br>₹<?=number_format($r['price'],2)?> × <?=$r['qty']?></div><div>₹<?=number_format($r['subtotal'],2)?> <a href="?remove=<?=$r['id']?>">Remove</a></div></div><?php endforeach; ?>
<h2>Total: ₹<?=number_format($total,2)?></h2>
<form method="post" class="inline"><button name="clear">Clear Cart</button><a class="button" href="checkout.php">Proceed to Checkout</a></form>
</div><?php endif; ?></main></body></html>