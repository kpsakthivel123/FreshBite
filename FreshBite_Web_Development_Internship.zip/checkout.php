<?php
session_start(); require "db.php";
if (empty($_SESSION['cart'])) { header("Location: cart.php"); exit; }
$cart=$_SESSION['cart']; $total=0; $ids=implode(',',array_map('intval',array_keys($cart)));
$res=$conn->query("SELECT * FROM menu_items WHERE id IN ($ids)");
while($r=$res->fetch_assoc()) $total += $r['price']*$cart[$r['id']];
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name=trim($_POST['name']); $phone=trim($_POST['phone']); $address=trim($_POST['address']); $payment=$_POST['payment'];
    if ($name && $phone && $address) {
        $stmt=$conn->prepare("INSERT INTO orders(customer_name,phone,address,total,payment_method,status) VALUES(?,?,?,?,?,?)");
        $status="Placed"; $stmt->bind_param("sssdss",$name,$phone,$address,$total,$payment,$status);
        $stmt->execute(); $order_id=$stmt->insert_id;
        $stmt2=$conn->prepare("INSERT INTO order_items(order_id,item_id,quantity,price) VALUES(?,?,?,?)");
        foreach($cart as $id=>$qty){ $q=$conn->prepare("SELECT price FROM menu_items WHERE id=?"); $q->bind_param("i",$id); $q->execute(); $price=$q->get_result()->fetch_assoc()['price']; $stmt2->bind_param("iiid",$order_id,$id,$qty,$price); $stmt2->execute(); }
        $_SESSION['cart']=[]; header("Location: orders.php?success=$order_id"); exit;
    }
}
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Checkout</title><link rel="stylesheet" href="style.css"></head>
<body><header><div class="brand">🍴 FreshBite</div><nav><a href="index.php">Menu</a><a href="cart.php">Cart</a></nav></header>
<main><h1>Checkout</h1><form method="post" class="form">
<input name="name" placeholder="Customer Name" required><input name="phone" placeholder="Phone Number" required>
<textarea name="address" placeholder="Delivery Address" required></textarea>
<select name="payment"><option>Cash on Delivery</option><option>Demo Online Payment</option></select>
<h2>Total: ₹<?=number_format($total,2)?></h2><button type="submit">Place Order</button>
</form></main></body></html>